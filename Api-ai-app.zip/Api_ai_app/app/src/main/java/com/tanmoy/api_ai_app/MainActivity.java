package com.tanmoy.api_ai_app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import ai.api.AIListener;
import ai.api.RequestExtras;
import ai.api.android.AIConfiguration;
import ai.api.android.AIService;
import ai.api.model.AIError;
import ai.api.model.AIResponse;
import ai.api.model.Result;
import com.google.gson.JsonElement;
import java.util.Map;

import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.widget.Toast;
import static java.sql.Types.NULL;

public class MainActivity extends ActionBarActivity implements AIListener {
    private Button listenButton;
    private TextView resultTextView;
    private EditText inputView;
    private AIService aiService;
    private String msg = "";
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listenButton = (Button) findViewById(R.id.listenButton);
        resultTextView = (TextView) findViewById(R.id.resultTextView);
        resultTextView.setMovementMethod(new ScrollingMovementMethod());
        inputView = (EditText) findViewById(R.id.inputView);

        config("f0674d6d388749a28c5e476f4c823d73");
        if(!permission())
        {
            enablebutton();
        }

    }

    public void config(String token){
        final AIConfiguration config = new AIConfiguration(token,
                AIConfiguration.SupportedLanguages.English,
                AIConfiguration.RecognitionEngine.System);

        aiService = AIService.getService(MainActivity.this, config);
        aiService.setListener(MainActivity.this);

        Toast toast = Toast.makeText(getApplicationContext(), token, Toast.LENGTH_SHORT);
        toast.show();
    }

    private boolean permission()
    {
        if(Build.VERSION.SDK_INT>=23&& ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)!= PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},100);
            return true;
        }
        return false;
    }

    private void enablebutton() {
        listenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //aiService.startListening();
                String input = inputView.getText().toString();
                new DoTextRequestTask().execute(input);
            }
        });

    }

    public void onResult(final AIResponse response) {
        Result result = response.getResult();

        String parameterString = "";
        if (result.getParameters() != null && !result.getParameters().isEmpty()) {
            for (final Map.Entry<String, JsonElement> entry : result.getParameters().entrySet()) {
                parameterString += "(" + entry.getKey() + ", " + entry.getValue() + ") ";
            }
        }

        // Show results in TextView.
        resultTextView.setText("Query:" + result.getResolvedQuery() +
                "\nAction: " + result.getAction() +
                "\nParameters: " + parameterString);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==100)
        {
            if (grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                enablebutton();
            }
            else
            {
                permission();
            }
        }
    }

    @Override
    public void onError(final AIError error) {
        resultTextView.setText(error.toString());
    }
    @Override
    public void onListeningStarted() {}

    @Override
    public void onListeningCanceled() {}

    @Override
    public void onListeningFinished() {}

    @Override
    public void onAudioLevel(final float level) {}


    class DoTextRequestTask extends AsyncTask<String, Void, AIResponse> {
        private Exception exception = null;
        protected AIResponse doInBackground(String... text) {
            AIResponse resp = null;
            try {
                resp = aiService.textRequest(text[0], new RequestExtras());


            } catch (Exception e) {
                this.exception = e;
            }
            return resp;
        }
        protected void onPostExecute(AIResponse response) {
            if (this.exception == null) {
                // todo : handle the exception
            }
            Result result = response.getResult();


            msg = msg + ("ME:" + result.getResolvedQuery() + "\nBOT :" + result.getFulfillment().getSpeech() + "\n");
            resultTextView.setText(msg);

            // Show results in TextView.

        }
    }
}
